# Inside __init__.py
print("Rules of Thumb package loaded-mumy is here!")
